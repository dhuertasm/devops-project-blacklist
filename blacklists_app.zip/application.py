from app import application

if __name__ == '__main__':
    application.run(port=5000, debug=True)
